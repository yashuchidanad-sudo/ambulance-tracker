package com.example.ambulancesewa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
